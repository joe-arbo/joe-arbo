#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <stddef.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/wait.h>

const int READ_END = 0;
const int WRITE_END = 1;

int main (int argc, char **argv)
{
    /*
    argv[0] = dpipe
    argv[1] = wc
    argv[2] = gnetcat
    argv[3] = -l
    argv[4] = port (16037)
    */

    //Piping
    int pipe1_ends[2]; //pipe([3, 4])
    if (pipe(pipe1_ends) == -1)
        perror("pipe"), exit(1);

    int pipe2_ends[2]; //pipe([5, 6])
    if (pipe(pipe2_ends) == -1)
        perror("pipe"), exit(1);  


    //fork and error check
    pid_t childpid = fork();
    if (childpid == -1)
        perror("fork"), exit(1);

    if (childpid == 0) //if fork = 0 | child
    {
        //wc sys calls
        //print message 
        if (write(STDERR_FILENO, "Starting: wc\n", 13) == -1)
            perror("write");

        //remap file descriptors and close pipes
        dup2(pipe1_ends[WRITE_END], STDOUT_FILENO);
        close(pipe1_ends[WRITE_END]);
        close(pipe1_ends[READ_END]);

        //remap file descriptors and close pipes
        dup2(pipe2_ends[READ_END], STDIN_FILENO);
        close(pipe2_ends[READ_END]);
        close(pipe2_ends[WRITE_END]);

        //execvp
        char *argv_for_wc[] = {argv[1], NULL};
        execvp(argv[1], argv_for_wc);
    }
    else //else fork again
    {
        //fork and error check
        pid_t childpid2 = fork();
        if (childpid2 == -1)
            perror("fork"), exit(1);

        if (childpid2 == 0) //if fork = 0 | gnetcat
        {
            //gnetcat sys calls

            //print messsage
            if (write(STDERR_FILENO, "Starting: gnetcat\n", 18) == -1)
                perror("write");

            //remap file descriptors
            dup2(pipe1_ends[READ_END], STDIN_FILENO);
            dup2(pipe2_ends[WRITE_END], STDOUT_FILENO);

            //close pipes
            close(pipe2_ends[WRITE_END]);
            close(pipe1_ends[READ_END]);
            close(pipe1_ends[WRITE_END]);
            close(pipe2_ends[READ_END]);

            //execvp
            char *argv_for_gnetcat[] = {argv[2], argv[3], argv[4], NULL};
            execvp(argv[2], argv_for_gnetcat);
        }
    }

    //finish dpipe sys calls and exit
    close(pipe2_ends[WRITE_END]);
    close(pipe1_ends[READ_END]);
    close(pipe2_ends[READ_END]);
    close(pipe1_ends[WRITE_END]);

    wait(NULL);
    wait(NULL);
    exit(0);
}