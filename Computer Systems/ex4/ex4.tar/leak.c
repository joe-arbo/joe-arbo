#include <stdlib.h>

char* pointer;
char* pointer1;

struct nodePtr 
{
    char* pointer;
};

struct nodePtr* node;

int main() 
{
    //definitely lost
    node = malloc(1000);
    char *pointer2 = malloc(508);

    //indirectly lost
    node->pointer = malloc(400);
    node = NULL;

    //possibly lost
    pointer = malloc(600);
    pointer += 2;
    
    //still reachable
    pointer1 = malloc(100);

    return 0;
}