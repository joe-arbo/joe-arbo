#include <sys/types.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <assert.h>
#include <arpa/inet.h>

int main(int ac, char *av[])
{
    int fd = open(av[1], O_RDONLY);
    assert (fd != -1);

    off_t filesize = lseek(fd, 0, SEEK_END);
    assert (filesize != (off_t) -1);

    size_t pgsize = getpagesize();
    size_t mapsize = (filesize + pgsize - 1) & ~(pgsize-1);

    void *addr = mmap(NULL, mapsize, PROT_READ, MAP_PRIVATE, fd, 0);
    if (addr == MAP_FAILED) {
        perror("mmap"); exit(-1);
    }
    assert (close(fd) == 0);

    // access file data like memory
    u_int32_t *width = addr + 16;
    u_int32_t *height = addr + 20;

    u_int32_t widthNum = ntohl(*width);
    u_int32_t heightNum = ntohl(*height);

    printf("Width %d x Height %d\n", widthNum, heightNum);
    return 0;
}
