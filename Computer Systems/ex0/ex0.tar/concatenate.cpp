/*Concatenate.cpp
    Purpose: Copy stdin to stdout or copy a file stream to stdout.
    Prereqs: Must use the same copy method for both.
    Author:  Joseph Arbolino
    Date:    9/2/21
*/

#include <string.h>
#include <iostream>
#include <fstream>

//prints to stdout
void writeToOutput(std::istream* fileStream)
{
    char buff[1024];
    while(!fileStream->eof())
    {
        fileStream->read(buff, 1024);
        std::cout.write(buff, fileStream->gcount());
    } 
}

int main (int argc, char **argv)
{
    std::string hyphen = "-";
    if (argc < 2) 
        writeToOutput(&std::cin);
    else
    {
        //if file name is included
        for (int i = 1; i < argc; ++i)
        {
            if (argv[i] == hyphen)
            {
                writeToOutput(&std::cin);
            }
            else
            {
                std::ifstream file(argv[i]);
                writeToOutput(&file);
            }
        }
    }

    return 0;
} 